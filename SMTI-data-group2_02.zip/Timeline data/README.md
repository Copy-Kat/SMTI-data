# SMTI data sources repository

Contain all the sources with respect to the timeline.

The PDFs are obtained by capturing a print of each website where possible, some are the earliest records that can be found on TheWaybackMachine.
The images are from broken links where it is either lost in time or have been replaced with something else with no records to be found on TheWaybackMachine.

The sources are from reputable sources like popular blog posts and CommandFusion website itself. Their Facebook page is another source we used to fill in some of the holes.
